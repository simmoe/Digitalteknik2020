
var element = document.getElementsByTagName("video")

var video = element.item(0)

console.log(video)